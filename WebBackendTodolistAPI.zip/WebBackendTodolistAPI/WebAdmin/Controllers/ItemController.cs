﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace WebAdmin.Controllers
{
    public class ItemController : Controller
    {
        public IActionResult Index()
        {
            ViewBag.itemtodolist_api_url = ConnectAPI.itemtodolist_api_url;
            return View();
        }


        public IActionResult Create()
        {
            ViewBag.itemtodolist_api_url = ConnectAPI.itemtodolist_api_url;
            return View();
        }

        public IActionResult Edit(int id)
        {
            ViewBag.itemtodolist_api_url = ConnectAPI.itemtodolist_api_url;
            ViewBag.id = id;
            return View();
        }
    }
}