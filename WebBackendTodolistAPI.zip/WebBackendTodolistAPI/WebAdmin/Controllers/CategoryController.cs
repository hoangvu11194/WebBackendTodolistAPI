﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using WebAdmin.Models;

namespace WebAdmin.Controllers
{
    public class CategoryController : Controller
    {
        public IActionResult Index()
        {
            ViewBag.category_api_url = ConnectAPI.category_api_url;
            return View();
        }

        public IActionResult Create()
        {
            ViewBag.category_api_url = ConnectAPI.category_api_url;
            return View();
        }

        public IActionResult Edit(int id)
        {
            ViewBag.category_api_url = ConnectAPI.category_api_url;
            ViewBag.id = id;
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
