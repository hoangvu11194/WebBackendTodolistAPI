﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAdmin
{
    public class ConnectAPI
    {
        public static string category_api_url= "http://localhost:55189/api/CategoryItems/";
        public static string itemtodolist_api_url= "http://localhost:55189/api/Items/";
    }
}
