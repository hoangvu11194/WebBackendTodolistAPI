﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebBackendTodolistAPI.Models;

namespace WebBackendTodolistAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryItemsController : Controller
    {
        ApplicationDbContext db = new ApplicationDbContext();
        // GET api/CategoryItems
        [HttpGet]
        public List<Category> Get()
        {
            using (ApplicationDbContext db = new ApplicationDbContext())
            {
                return db.Categories.ToList();
            }
        }
        // GET api/CategoryItems/1
        [HttpGet("{id}")]
        public Category Get(int id)
        {
            using (ApplicationDbContext db = new ApplicationDbContext())
            {
                return db.Categories.FirstOrDefault(m => m.Id == id);
            }
        }


        // POST api/CategoryItems
        [HttpPost]
        public IActionResult Post([FromBody]Category obj)
        {
            using (ApplicationDbContext db = new ApplicationDbContext())
            {
                if (ModelState.IsValid)
                {
                    db.Categories.Add(obj);
                    db.SaveChanges();
                    return Ok();
                }
                return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(modelError => modelError.ErrorMessage).ToList());
            }
        }

        // PUT api/CategoryItems/1
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody]Category obj)
        {
           
                if (ModelState.IsValid)
                {
                    db.Entry<Category>(obj).State = EntityState.Modified;
                    db.SaveChanges();
                    return Ok();
                }
                return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(modelError => modelError.ErrorMessage).ToList());
            
        }



        // DELETE api/CategoryItems/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            using (ApplicationDbContext db = new ApplicationDbContext())
            {
                db.Categories.Remove(db.Categories.Find(id));
                db.SaveChanges();
                return Ok();
            }
        }
    }
}