﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebBackendTodolistAPI.Models;

namespace WebBackendTodolistAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ItemsController : ControllerBase
    {
        ApplicationDbContext db = new ApplicationDbContext();
        [HttpGet]
        public List<Item> Get()
        {
            using (ApplicationDbContext db = new ApplicationDbContext())
            {

                return db.Items.OrderByDescending(n=>n.DueDate).ToList();
            }
        }

        [HttpGet("{id}")]
        public Item Get(int id)
        {
            using (ApplicationDbContext db = new ApplicationDbContext())
            {
                return db.Items.FirstOrDefault(m => m.Id == id);
            }
        }
        //Get api/Items?description
        //[HttpGet]
        //public List<Item> GetItemsByBrand(string description)
        //{
        //    using (ApplicationDbContext db = new ApplicationDbContext())
        //    {
        //        if (description != null )//filter by categoryname (input search)
        //            return db.Items.FromSql("SELECT * FROM dbo.Items WHERE Description like " + "'%" + description.ToString() + "%'" + " order by DueDate des").ToList();


        //        return db.Items.OrderByDescending(n => n.DueDate).ToList();
        //    }
        //}



        // POST api/Items
        [HttpPost]
        public IActionResult Post([FromBody]Item obj)
        {
            
            
                if (ModelState.IsValid)
                {
                    db.Items.Add(obj);
                    db.SaveChanges();
                    return Ok();
                }
                return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(modelError => modelError.ErrorMessage).ToList());
            
        }

        // PUT api/Items/1
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody]Item obj)
        {
            using (ApplicationDbContext db = new ApplicationDbContext())
            {
                if (ModelState.IsValid)
                {
                    db.Entry<Item>(obj).State = EntityState.Modified;
                    db.SaveChanges();
                    return Ok();
                }
                return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(modelError => modelError.ErrorMessage).ToList());
            }
        }



        // DELETE api/CategoryItems/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            using (ApplicationDbContext db = new ApplicationDbContext())
            {
                db.Items.Remove(db.Items.Find(id));
                db.SaveChanges();
                return Ok();
            }
        }
    }
}